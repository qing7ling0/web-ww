module.exports.companys = [
  {value:'1', label:'圆通'},
  {value:'2', label:'申通'},
  {value:'3', label:'顺风'},
]