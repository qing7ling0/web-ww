module.exports = {
  _id: "1",
  name: '管理员',
  sex: '男',
  power: 1000,
  user_type: 4,
  account: {
    account: 'lq-1212',
    password: '1212-lq',
  }
}