
import * as queries from './queries'
import * as mutations from './mutations'

export default {queries, mutations}