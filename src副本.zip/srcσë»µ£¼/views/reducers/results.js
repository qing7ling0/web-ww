'use strict'

var results =[];

export default results;