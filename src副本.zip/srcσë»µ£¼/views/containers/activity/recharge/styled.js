import styled from 'styled-components'

import {
  Card,
  Input,
  Button,
  Row,
  Col,
  Select
} from 'antd'

export const Root = styled.div`
`
export const Container = styled.div`
  display: inline-block;
  vertical-align: middle;
`