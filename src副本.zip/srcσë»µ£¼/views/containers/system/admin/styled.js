import styled from 'styled-components'

import {
  Card,
  Input,
  Button,
  Row,
  Col,
} from 'antd'

export const Root = styled.div`
`


/** add began */
export const AddRoot = styled.div`

`
/** add end */